document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',()=>{}));
document.getElementById('contactForm').addEventListener('submit',function(e){
  e.preventDefault();
  const d=new FormData(this);
  const subject=encodeURIComponent('Video Editing Project Inquiry from '+d.get('name'));
  const body=encodeURIComponent(`Name: ${d.get('name')}\nEmail: ${d.get('email')}\nProject Type: ${d.get('project')}\n\nMessage:\n${d.get('message')}`);
  window.location.href=`mailto:sonamkale2565@gmail.com?subject=${subject}&body=${body}`;
});
