# Sonam Kale — Audio & Video Editor Portfolio

Static HTML/CSS/JavaScript portfolio ready for GitHub Pages.

## Add your files
- Put the Italy travel video at `assets/videos/travel-italy.mp4`
- Put the minimalist design video at `assets/videos/minimalist-design.mp4`
- Put your certificate PDF at `assets/certificates/certificate.pdf`

If your files have different names, update the paths in `index.html`.

## Publish on GitHub Pages
1. Create a GitHub repository, e.g. `video-editor-portfolio`.
2. Upload all files and folders.
3. Go to **Settings → Pages**.
4. Under Build and deployment choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will provide the live Pages URL.

## Note
This project does not include invented certificates, experience, reviews, or project claims.
